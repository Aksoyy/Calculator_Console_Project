package example;

import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Random;

public class exam 
{
	public static void main(String[] args)
	{
		double sayi1,sayi2,sonuc;
		double sayilar[] = new double[2];
		int menu,faktoriyel,sinir;
		do
		{
			menu = MenuSecim();
			switch(menu)
			{
				case 1:
					System.out.println("1. sayiyi giriniz : "); sayi1 = OndalikSayiAl();
					System.out.println("2. sayiyi giriniz : "); sayi2 = OndalikSayiAl();                                                 
					sonuc = Toplam(sayi1,sayi2);
					SonucGoster(sonuc);		
					break;
				case 2:
					for( int i=0;i<2;i++ )                               //sayi1 = OndalikSayiAl();
					{                                                    //sayi2 = OndalikSayiAl();
						System.out.println((i+1)+" . sayiyi giriniz : ");  //sonuc = Cikar(sayi1,sayi2);
						sayilar[i] = OndalikSayiAl();                    //SonucGoster(sonuc);
					}	                                                 
					sonuc = Cikar(sayilar[0],sayilar[1]);
					SonucGoster(sonuc);
					break;
/*	*/			case 3:
					for( int i=0;i<2;i++ )                               //sayi1 = OndalikSayiAl();
					{                                                    //sayi2 = OndalikSayiAl();
						System.out.println(i+1+" . sayiyi giriniz : ");  //sonuc = Carpim(sayi1,sayi2);
						sayilar[i] = OndalikSayiAl();                    //SonucGoster(sonuc);
					}	                                                 
					sonuc = Carpim(sayilar[0],sayilar[1]);
					SonucGoster(sonuc);
					break;
				case 4:
					for( int i=0;i<2;i++ )                               //sayi1 = OndalikSayiAl();
					{                                                    //sayi2 = OndalikSayiAl();
						System.out.println(i+1+" . sayiyi giriniz : ");  //sonuc = Bolme(sayi1,sayi2);
						sayilar[i] = OndalikSayiAl();                    //SonucGoster(sonuc);
					}	                                                 
					sonuc = Bolme(sayilar[0],sayilar[1]);
					SonucGoster(sonuc);
					break;
				case 5:
					System.out.println("Lutfen bir tam sayi giriniz : ");
					faktoriyel = TamSayiAl();
					sonuc = Fakto(faktoriyel);
					SonucGoster(sonuc);
					break;
				case 6:
					System.out.println("Rastgele sayi uretimi icin siniri belirleyiniz : ");
					sinir = TamSayiAl();
					sonuc = Rastgele_Tam_sayi(sinir);
					SonucGoster(sonuc);
					break;
				case 7:
					System.out.println("Cikis islemi basladi.");
					break;
				default:
					Scanner goster = new Scanner(System.in);
					System.out.println("-Belirlenen aralikta bir deger giriniz-");
					System.out.println("Tekrar secim yapmak icin enter'a basiniz");
					goster.nextLine();
					break;
			}
		}
		while( menu!=7 );
		System.out.println("Cikis yapıldi");
	}
	
	public static void MenuOpen()
	{
		System.out.println("LUTFEN YAPILACAK ISLEMI SECINIZ\n"+
				 	"1-Toplama islemi\n"+
					"2-Cikarma islemi\n"+
					"3- Carpma islemi\n"+
					"4- Bolme islemi\n"+
					"5- Faktoriyel islemi\n"+
					"6- Rastgele sayi uretimi\n+"+
					"7- Cikis komutu \n");
	}
	
	public static int MenuSecim()
	{
		Scanner open = new Scanner(System.in);
		System.out.println("Lutfen seciminizi yapiniz : ");
		MenuOpen();
		
		int sayi;
		sayi=open.nextInt();
		
		return sayi;
	}

	public static double OndalikSayiAl()
	{
		 double sayi;				//Scanner open = new Scanner(System.in);
			while (true)    		//double sayi = open.nextDouble();
			{	                    //return sayi;*/
				try
	            {
	                Scanner scan = new Scanner(System.in);
	                sayi = scan.nextDouble();
	                return sayi;
	            } 
	            catch (InputMismatchException e) 
	            {
	                System.out.println("Hata: Lütfen double tipinde bir sayı giriniz!");
	            }
	       }
	}
	
	public static double Toplam(double param1,double param2)
	{
		return param1+param2;
	}
	public static double Cikar(double param1,double param2)
	{
		return param1-param2;
	}
	public static double Bolme(double param1,double param2)
	{
		return param1/param2;
	}
	public static double Carpim(double param1,double param2)
	{
		return param1*param2;
	}
	
	public static int TamSayiAl()
	{
	        int sayi;
			while (true) 
	        {
	            try
	            {
	                Scanner scan = new Scanner(System.in);
	                sayi = scan.nextInt();
	                if(sayi<1)
	                {
	                	return 0;
	                }
	                return sayi;
	            } 
	            catch (InputMismatchException e) 
	            {
	                System.out.println("Hata: Lütfen integer tipinde bir sayı giriniz!");
	            }
	       }
	}
	
	public static int Fakto(int alinan_deger)
	{
		if(alinan_deger<1) return 0;
		int fakt=1;
		for(int i=1; i<=alinan_deger; i+=1 )
		{
			fakt *= i;
		}
		return fakt;
	}

	public static int Rastgele_Tam_sayi(int num)
	{
		Random randomNum = new Random();
		return randomNum.nextInt(num)+1;
	}
	
	public static void SonucGoster( double param)
	{
		Scanner goster = new Scanner(System.in);
		System.out.println("Islemin sonucu : "+param);
		System.out.println("Islemlerin devam etmesi icin enter'a basiniz");
		goster.nextLine();
	}
}